module.exports = async () => ({ statusCode: 200, body: 'ok from tf-manual' });
