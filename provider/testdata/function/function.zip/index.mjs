import{createRequire as ___cr}from'module';import{fileURLToPath as ___f}from'url';import{dirname as ___d}from'path';const require=___cr(import.meta.url);const __filename=___f(import.meta.url);const __dirname=___d(__filename);

// index.ts
var index_default = {
  fetch: (_) => {
    const env = process.env;
    const body = Object.keys(env).length === 0 ? "Hello world!" : JSON.stringify(env);
    return new Response(body, {
      headers: { "content-type": "text/plain; charset=utf-8" }
    });
  }
};
export {
  index_default as default
};
